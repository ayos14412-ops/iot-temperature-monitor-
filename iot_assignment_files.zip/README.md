# Python-Based IoT Temperature Monitoring System

## Project Overview
This project simulates an Internet of Things (IoT) temperature monitoring system using Python.

## Files Included
- `iot_temperature_monitor.py`
- `temperature_readings.csv`
- `temperature_graph.png`
- `README.md`
